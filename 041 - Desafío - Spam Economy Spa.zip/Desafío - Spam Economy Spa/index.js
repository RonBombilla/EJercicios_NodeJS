const http = require("http");
require("dotenv").config();
const { v4: uuidv4 } = require("uuid");
const nodemailer = require("nodemailer");
const url = require("url");
const fs = require("fs");
const axios = require("axios");

function send(correos, asunto, contenido) {
  return new Promise(async (resolve, reject) => {
    axios.get("https://mindicador.cl/api").then((data) => {
      const dolar = data.data.dolar.valor;
      const euro = data.data.euro.valor;
      const uf = data.data.uf.valor;
      const utm = data.data.utm.valor;
      const templateIndicadores = `
      <br>
      <p> El valor del dolar el día de hoy es: ${dolar} </p>
      <p> El valor del euro el día de hoy es: ${euro} </p>
      <p> El valor del uf el día de hoy es: ${uf} </p>
      <p> El valor del utm el día de hoy es: ${utm} </p>`;

      let transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: "email.test.backend@gmail.com",
          pass: "backendtesting",
        },
      });

      let mailOptions = {
        from: "email.test.backend@gmail.com",
        to: correos,
        subject: asunto,
        html: contenido + templateIndicadores,
      };

      transporter.sendMail(mailOptions, (err, data) => {
        if (err) {
          reject(err);
        } else {
          fs.writeFile(
            `correos/${uuidv4()}.txt`,
            contenido,
            "utf8",
            () => {
              resolve(data);
            }
          );
        }
      });
    });
  });
}

http
  .createServer(async function (req, res) {
    let { correos, asunto, contenido } = url.parse(req.url, true).query;
    res.setHeader("content-type", "text/html");

    if (req.url.startsWith("")) {
      fs.readFile("index.html", "utf8", (err, data) => {
        res.write(data);
      });
    }

    if (req.url.startsWith("/mailing")) {
      res.setHeader("content-type", "text/html");

      correos = correos.split(",");

      send(correos, asunto, contenido)
        .then((data) => {
          console.log(data);
          res.write(
            `
          <p class="alert alert-info w-25 m-auto text-center"> Correos enviados con éxito =)</p>
          `,
            (err) => {
              res.end();
            }
          );
        })
        .catch((err) => {
          console.log(err);
          res.write(
            `
              <p class="alert alert-danger w-25 m-auto text-center"> Sorry... algo salió mal =( </p>
            `,
            (err) => {
              res.end();
            }
          );
        });
    }

  })
  .listen(8080, () => console.log(`Server running on port 8080 and process ID ${ process.pid }...`));
