const http = require("http");
const axios = require ("axios");
const { v4: uuid } = require("uuid");
const chalk = require("chalk");
const moment = require("moment");
const _ = require("lodash");
const { bgWhite } = require("chalk");

let users= [];

http
  .createServer((req, res) => {
    if(req.url.startsWith('/users')){
        res.writeHead(200, { 'content-type': 'text/html' });
        axios.get("https://randomuser.me/api/")
        .then ((data) => {
            const { first, last } = data.data.results[0].name;
            let fecha= moment().format('MMMM Do YYYY, h:mm:ss a');
            users.push({ first, last, id: uuid(), fecha });
        })
        .catch((error) => {
            console.log(error)
        });

        res.write('<ol>');
        _.forEach(users, (u) => { 
           const gottenUser = [u.first, u.last,u.id, u.fecha];
            res.write(`<li>Nombre:${u.first} Apellido:${u.last} ID:${u.id} Fecha:${u.fecha}</li>`); 
            console.log(chalk.blue.bgWhite(gottenUser));
        });   
        res.write('</ol>');
        res.end();
    }
  })
  .listen(8080, () => {
    console.log("Puerto 8080");
  });
