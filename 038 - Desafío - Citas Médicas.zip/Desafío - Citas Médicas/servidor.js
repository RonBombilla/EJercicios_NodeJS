http
  .createServer((req, res) => {
    console.log(req.url);
    const url = req.url;
  })
  .listen(8080, () => {
    console.log("Puerto 8080");
  });
