const axios = require('axios');
const http = require('http');
const fs = require('fs');

let poke = [];
let pokemones = [];

async function getPokemon(){
    const{data} = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=150')
    const pokemon = data.results;
    return pokemon
}

async function getImagen(nombre){
    const {data} = await axios.get(`https://pokeapi.co/api/v2/pokemon/${nombre}`)
    //console.log(data)
    return data
}

getPokemon().then((results) => {
    results.forEach((e) => {
        let nombre = e.name;
        //console.log(nombre)
        poke.push(getImagen(nombre));
    })
    //console.log(poke)
    Promise.all(poke).then((data) => {
        //console.log(data)
        data.forEach((e) => {
            const nombre = e.name;
            const img = e.sprites.front_default;
            pokemones.push({nombre, img})
        })
        //console.log(pokemones);

        http.createServer((req, res) => {
            if (req.url.includes('/')) {
                res.writeHead(200, { 'Content-Type': 'text/html' })
                fs.readFile('./index.html', 'utf8', (err, html) => {
                    if (err) {
                        console.log(err)
                    }
                    res.write(html);                    
                })
            }
            
            if (req.url.includes('/pokemones')) {
                res.writeHead(200, { 'Content-Type': 'application/json' })
                res.end(JSON.stringify(pokemones))
            }
        }).listen(3000, () => console.log('Listening server in http://localhost:3000'))
    })
})


