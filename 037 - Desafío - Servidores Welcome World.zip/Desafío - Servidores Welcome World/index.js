//modulos
const http = require('http');
const url = require('url');
const fs = require('fs');
//creando server con node
http.createServer((req, res) => {
    const params = url.parse(req.url, true).query;
    const archivo = params.archivo;
    const contenido = params.contenido;
    const Nuevo_nombre = params.nuevoNombre;
    const nombre = params.nombre;

    if (req.url.includes('/crear')) {
        //rescato la fecha actual
        let ts = Date.now();
        //los paso a objetos
        let date_ob = new Date(ts);
        let date = date_ob.getDate();
        let month = date_ob.getMonth() + 1;
        let year = date_ob.getFullYear();

        // muestro la fecha en formato DD/MM/AAAA
        console.log(date + "-" + month + "-" + year);
        let fecha = `${date < 10 ? '0' + date : date}/${month < 10 ? '0' + month : month}/${year}`;
        fs.writeFile(archivo, contenido +" "+ `${fecha}`, () => {
            res.write('Archivo creado con éxito!')
            res.end()
        })
    }
    if (req.url.includes('/leer')) {
        fs.readFile(archivo, (err, data) => {
            res.write(data)
            res.end()
        })
    }
    if (req.url.includes('/renombrar')) {
        fs.rename(nombre, Nuevo_nombre, (err, data) => {
            res.write(`${nombre} renombrado por ${Nuevo_nombre}`)
            res.end()
        })
    }
    if (req.url.includes('/eliminar')) {
        res.write(`Tu solicitud para eliminar el archivo ${archivo} se está
                procesando...`)
        setTimeout(() => {
            fs.unlink(archivo, (err, data) => {
                
                res.write(` El archivo ${archivo} se ha eliminado con exito`)
                res.end()
            })
            }, 3000)
    }
}).listen(8080, () => {
    console.log('escuchando el puerto 8080');
});