const yargs = require('Yargs');
const child = require('child_process');

const argv = yargs.command(
    'img',
    'servidor para levantamiento de imagen',
    {
        key:{
            describe: '',
            demand: true,
            alias: 'k',
        },
    },(args)=>{
        args.key == 123 ? child.exec('nodemon imagen.js', (err, stdout) => {
                err ? console.log(err) : console.log(stdout)
            })
            : console.log('Llave de acceso incorrecta')
    }).help().argv