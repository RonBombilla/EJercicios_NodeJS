const Jimp = require('jimp');
const http = require('http');
const fs = require('fs');
const url = require('url');

http.createServer((req, res) => {
    if(req.url == '/'){
        res.writeHead(200, {"content-type":"text/html"});
        fs.readFile('index.html','utf8',(err, html) => {
            res.end(html);
        })
    }
    if(req.url == '/cargarimagen'){
        const params = url.parse(req.url, true).query;
        Jimp.read(params.url_imagen,
            (err, imagen)=>{
                imagen.resize(350, Jimp.AUTO)
                .greyscale()
                .quality(60)
                .writeAsync('newimg.jpg')
                .then(() => {
                    fs.readFile("newimg.jpg",(err, image) => {
                        res.writeHead(200,{"content-type":"image/jpeg"});
                        res.end(image);
                    })
                })
            })
    }
    if(req.url == '/style'){
        res.writeHead(200, {"content-type":"text/css"});
        fs.readFile('style.css',(err , css)=>{
            res.end(css);
        })
    }
}).listen(8080, () => console.log('Listening server in port 8080...'));