const https =  require("https");
const fs =  require('fs')
const argumentos = process.argv.slice(2)
console.log(argumentos)
let nom = argumentos[0]
var ind = argumentos[1]
var peso = argumentos[2]
 
https
 .get("https://mindicador.cl/api/", (res) => {
 let datos = [];
 res
 .on("data", (d) => {
 datos.push(d);
 })
 .on("end", () => {
    let data_concat = Buffer.concat(datos);
    let monedas = JSON.parse(data_concat)
    //console.log(monedas)
    let valor = monedas[`${ind}`].valor
    let fecha = monedas.fecha
    let uni = monedas[`${ind}`].unidad_medida
    let nombre = monedas[`${ind}`].nombre

    
    if (uni == "Pesos") {
      let resultado = peso / valor

      fs.writeFile(`${nom}`, `A la fecha: ${fecha}
      Fue realizada cotización con los siguientes datos:
      Cantidad de pesos a convertir: ${peso} pesos
      Convertido a ${nombre} da un total de: ${resultado} `, 'utf8', () => {
            console.log('Archivo creado')})

            fs.readFile(`${nom}`, 'utf8', (err, data) => {
              console.log('Contenido del archivo: ' + data)
            })
      
      
    }
  
    if (uni == "Dólar") {
      let resultado = (peso / monedas.dolar.valor) / valor
      
      fs.writeFile(`${nom}`, `A la fecha: ${fecha}
      Fue realizada cotización con los siguientes datos:
      Cantidad de pesos a convertir: ${peso} pesos
      Convertido a ${nombre} da un total de: ${resultado} `, 'utf8', () => {
            console.log('Archivo creado')})

            fs.readFile(`${nom}`, 'utf8', (err, data) => {
              console.log('Contenido del archivo: ' + data)
            })

    }

  });
 })
 .on("error", (e) => {
 console.error(e);

 });

