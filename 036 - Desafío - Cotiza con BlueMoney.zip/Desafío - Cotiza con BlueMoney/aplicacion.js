const child_process = require("child_process");

let ejecutar = (archivo) => {
  return new Promise((resolve) => {
    child_process.exec(`node ${archivo}`, function (err, result) {
      resolve(String(result));
    });
  });
};
function crearArhivo(nom, ind, peso) {
  console.log(nom, ind, peso + 'aqui')
  return new Promise((resolve) => {
    child_process.exec(
      `node blueMoney.js ${nom} ${ind} ${peso}`,
      function (err, result) {
      resolve(String(result));
      }
    );
  });
}

let final = () => {
  let nom = "";
  let ind = "";
  let peso = null;

  ejecutar("nombre.js").then((nombre) => {
    nom = nombre;
    ejecutar("indi.js").then((indi) => {
      ind = indi;
      ejecutar("xpeso.js").then((xpeso) => {
        peso = xpeso;
        console.log(peso, ind, nom);
        crearArhivo(nom, ind, peso);
      });
    });
  });
};

final();