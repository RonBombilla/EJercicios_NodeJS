const child_process = require("child_process");
const https = require("https");

body = []
https
.get("https://mindicador.cl/api", (request) => {

    request.on('data', (chunk) => {
      body.push(chunk);
    }).on('end', () => {
      body = JSON.parse(Buffer.concat(body));
    });
})
.on("error", (e) => {
console.error(e);
});